// Copyright 2009-2011 The MathWorks, Inc.

#ifdef SUPPORTS_PRAGMA_ONCE
#pragma once
#endif

#ifndef CGIR_CONSTRUCT_FROM_RTWCG_HPP
#define CGIR_CONSTRUCT_FROM_RTWCG_HPP
#include "../sl_core_block_spec.hpp"
#include "sfun_rtwcg.hpp"
#endif
