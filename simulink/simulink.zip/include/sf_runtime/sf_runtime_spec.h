/* Copyright 2013 The MathWorks, Inc. */

#ifndef sf_runtime_spec_h
#define sf_runtime_spec_h

#ifdef __cplusplus
#define LIBMWSF_RUNTIME_API extern "C"
#else
#define LIBMWSF_RUNTIME_API extern
#endif

#endif
