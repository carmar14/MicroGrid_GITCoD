/* Copyright 2016 The MathWorks, Inc. */
/*
  dl_logger_type.h
  libmwsl_services

  Created by dima on 7/16/16.
*/

#ifndef dl_logger_type_hpp
#define dl_logger_type_hpp

typedef void* dl_logger_sid_t;

#endif /* dl_logger_type_hpp */
